create table clientes (
codigo mediumint not null,
nome varchar(50) not null,
telefone varchar(30) not null,
email varchar(50) not null,
observacao varchar(255),
primary key (codigo)
);
